// // load script require

// const array_scripts  = [
//     "app",
//     "accessFBtoDB",
//     "clockJs",
//     "state-city",
//     "autocompleteCity",
//     "index"
// ];  
// var tags_scripts = '' ; 
// $(array_scripts).each(function(i,script){
//     var createdElement =document.createElement('script') ; 
//     createdElement.src = script ; 

// });

// var imported = document.createElement('script');
// imported.src = 'cliente.js';
// document.head.appendChild(imported); 
